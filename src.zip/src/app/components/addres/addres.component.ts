import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addres',
  templateUrl: './addres.component.html',
  styleUrls: ['./addres.component.css']
})
export class AddresComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
