export interface Reservation {
  id?: string;
  fairName?: string;
eduLevel?: string;
eduOffice?: string;
schoolName?: string;
schoolPhone?: string;
studentNumber?: number;
teacherName?: string;
teacherPhone?: string;
visitDate?: Date;
visitTime?: string;
}
