export interface Settings {
  isRegisterOpen?: boolean;
  canAddFair?: boolean;
  id?: string;

}
