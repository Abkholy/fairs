export interface Fair {
  id?: string;
  fairName?: string;
  fromDate?: Date;
  toDate?: Date;
  Location?: string;
  noOfSchools?: number;

}
