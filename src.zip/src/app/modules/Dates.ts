export interface Dates {
  date?: Date;
}
