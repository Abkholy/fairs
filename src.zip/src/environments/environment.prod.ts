export const environment = {
  production: true ,
  firebase: {
    apiKey: 'AIzaSyBpjxnYEDJg36Msc2C1wSN0O-fmrozgjV4',
    authDomain: 'fairbooking-200319.firebaseapp.com',
    databaseURL: 'https://fairbooking-200319.firebaseio.com',
    projectId: 'fairbooking-200319',
    storageBucket: 'fairbooking-200319.appspot.com',
    messagingSenderId: '416031461015'
}
};
